#!/bin/sh

./etcd-v3.1.9-linux-amd64/etcd > start-etcd.log 2>&1 &
sleep 5
./service-center > start-sc.log 2>&1 &
