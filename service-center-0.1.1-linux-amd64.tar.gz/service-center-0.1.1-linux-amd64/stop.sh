kill -9 $(ps aux | grep 'service-center' | awk '{print $2}')
kill -9 $(ps aux | grep 'etcd' | awk '{print $2}')

